/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parce_cub.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adiouane <adiouane@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/25 19:15:59 by adiouane          #+#    #+#             */
/*   Updated: 2022/08/25 19:44:40 by adiouane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include <cub3D.h>

void	parsing(char *str)
{
	int		fd;
	char	*ext;
	t_map	*data;

	data = malloc(sizeof(t_map));
	ext = ft_strrchr(str, '.');
	if (ft_strncmp(ext, ".cub\0", 5))
		exit_error("invalid file extension", ext);
	fd = open(str, O_RDONLY);
	if (fd == -1)
		exit_strerr(str, errno);
	data->map = ft_set_map(fd);
	init_map(data);
	init_mlx(data);
	// printf("%s\n", data.no);
	// printf("%s\n", data.so);
	// printf("%s\n", data.we);
	// printf("%s\n", data.ea);
	// printf("%s\n", data.floor_color);
	// printf("%s\n", data.ceiling_color);
	// close(fd);
	
	data->direction = RIGHT;
	draw_map(data);
	mlx_hook(data->mlx_win, 2, 0, ft_move, data);
	mlx_loop(data->mlx);
	// printf("Everything looks good\n");
}
