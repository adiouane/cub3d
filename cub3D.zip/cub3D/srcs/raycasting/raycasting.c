/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycasting.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: adiouane <adiouane@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/02 11:31:26 by adiouane          #+#    #+#             */
/*   Updated: 2022/09/03 22:52:17 by adiouane         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D.h>

void	raycasting(t_map *data)
{
    // float    posx;
    // float    posy;
    // float    dirx;
    // float    diry;
    // float    pa;
    (void)data;
}